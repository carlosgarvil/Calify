# Calify

Esta extensión permite copiar las notas del primer Criterio de evaluación en el resto de Criterios del cuaderno Séneca.

Esta función ya existía en Séneca como clonarCalificacionF8() pero no estaba anunciada. En algún momento la hicieron desaparecer del código y ahí se me ocurrió hacer un addon del navegador.

La extensión toma como base el ejemplo Beastify (que proporciona Firefox) y que permite insertar código JS y CSS en la pestaña activa.

En el repositorio tenéis el archivo XPI y los archivos no están minimizados, por lo que el código se puede ver simplemente renombrando el archivo a .ZIP

Entiendo que esta función volverá a Séneca más pronto que tarde, pero mientras tanto espero que os ahorre tanto tiempo como a mí.